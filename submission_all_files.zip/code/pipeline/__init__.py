"""Pipeline package."""
